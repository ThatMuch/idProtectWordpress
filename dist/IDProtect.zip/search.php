<?php
/*
Template Name: Search Page
*/
?>
<?php
get_header(); ?>
<?php get_template_part('templates/wp', 'home'); ?>
<?php get_footer();
