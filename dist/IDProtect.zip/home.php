<?php get_template_part('templates/wp', 'home'); ?>
